


// import React, { useState, useEffect } from "react";
// import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";

// const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

// const Chart = ({ currMonth }) => {
//   const [circle, setPieChart] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const months = [
//     "January", "February", "March", "April", "May", "June",
//     "July", "August", "September", "October", "November", "December",
//   ];

//   // Fetch data from the API
//   const fetchPieChartData = async () => {
//     try {
//       setLoading(true);
//       setError(null);
//       const response = await fetch(
//         `https://transactionapi-y297.onrender.com/transactionPieChart/${currMonth}`
//       );
//       if (!response.ok) {
//         throw new Error("Failed to fetch data");
//       }
//       const data = await response.json();
//       setPieChart(data);
//     } catch (err) {
//       setError(err.message);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchPieChartData();
//   }, [currMonth]);

//   if (loading) {
//     return (
//       <div className="text-center mt-3">
//         <p>Loading chart data...</p>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="text-center text-danger mt-3">
//         <p>Error: {error}</p>
//       </div>
//     );
//   }

//   return (
//     <div className="container text-center">
//       <h5 className="text-dark">
//         Item-Category Chart for {months[currMonth - 1]}
//       </h5>
//       <div className="row justify-content-center">
//         <div className="col-12 col-md-8 col-lg-6">
//           <ResponsiveContainer width="100%" height={400}>
//             <PieChart>
//               <Pie
//                 data={circle}
//                 dataKey="value"
//                 nameKey="name"
//                 cx="50%"
//                 cy="50%"
//                 outerRadius="70%"
//                 fill="#8884d8"
//                 label
//               >
//                 {circle.map((entry, index) => (
//                   <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
//                 ))}
//               </Pie>
//               <Tooltip />
//               <Legend />
//             </PieChart>
//           </ResponsiveContainer>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Chart;

import React, { useState, useEffect } from "react";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";

const COLORS = [
  '#3498db', // Blue
  '#2ecc71', // Green
  '#e74c3c', // Red
  '#f39c12', // Orange
  '#9b59b6', // Purple
  '#1abc9c', // Turquoise
  '#34495e', // Dark Blue-Gray
  '#e67e22', // Carrot Orange
];

const Chart = ({ currMonth }) => {
  const [circle, setPieChart] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];

  // Fetch data from the API
  const fetchPieChartData = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(
        `https://transactionapi-y297.onrender.com/transactionPieChart/${currMonth}`
      );
      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }
      const data = await response.json();
      setPieChart(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPieChartData();
  }, [currMonth]);

  // Custom tooltip for better styling
  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div 
          className="custom-tooltip" 
          style={{
            background: 'rgba(0,0,0,0.8)',
            color: 'white',
            padding: '12px',
            borderRadius: '8px',
            fontFamily: "'Inter', sans-serif"
          }}
        >
          <p className="label">{`${payload[0].name}: ${payload[0].value}`}</p>
          <p className="intro">{`Percentage: ${(payload[0].percent * 100).toFixed(2)}%`}</p>
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <div 
        className="d-flex justify-content-center align-items-center" 
        style={{ 
          height: '400px',
          background: 'linear-gradient(135deg, #f4f5f7 0%, #e9ecef 100%)',
          fontFamily: "'Inter', sans-serif"
        }}
      >
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div 
        className="text-center d-flex justify-content-center align-items-center text-danger" 
        style={{ 
          height: '400px',
          background: 'linear-gradient(135deg, #f4f5f7 0%, #e9ecef 100%)',
          fontFamily: "'Inter', sans-serif"
        }}
      >
        <p>Error: {error}</p>
      </div>
    );
  }

  return (
    <div 
      className="container-fluid text-center p-3" 
      style={{
        background: 'linear-gradient(135deg, #f4f5f7 0%, #e9ecef 100%)',
        fontFamily: "'Inter', sans-serif"
      }}
    >
      <h5 
        className="mb-4" 
        style={{ 
          color: '#2c3e50',
          fontSize: '1.5rem',
          fontWeight: 'bold'
        }}
      >
        Category Distribution - {months[currMonth - 1]}
      </h5>
      <div className="row justify-content-center">
        <div className="col-12 col-md-8 col-lg-6">
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={circle}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius="70%"
                fill="#8884d8"
                label={({ name, percent }) => `${name} (${(percent * 100).toFixed(1)}%)`}
                labelStyle={{ 
                  fontSize: '12px', 
                  fontFamily: "'Inter', sans-serif",
                  fill: '#2c3e50' 
                }}
              >
                {circle.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={COLORS[index % COLORS.length]} 
                    stroke="rgba(255,255,255,0.5)"
                    strokeWidth={2}
                  />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                layout="horizontal" 
                verticalAlign="bottom" 
                align="center"
                wrapperStyle={{
                  fontFamily: "'Inter', sans-serif",
                  color: '#2c3e50'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Chart;