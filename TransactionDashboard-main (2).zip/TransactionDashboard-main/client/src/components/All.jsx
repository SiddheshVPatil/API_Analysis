// import { useState, useRef } from "react";
// import Table from "./Table.jsx";
// import TransactionStatistic from "./TransactionStatistic.jsx";
// import Chart from "./PieChart.jsx";
// import BarChart from "./BarChart.jsx";

// function All() {
//   const [currMonth, setMonth] = useState(3);

//   // Create refs for each section
//   const tableRef = useRef(null);
//   const statisticRef = useRef(null);
//   const barChartRef = useRef(null);
//   const pieChartRef = useRef(null);
//   const scrollToSection = (ref) => {
//       ref.current.scrollIntoView({ behavior: "smooth" });
//   };

//   const updateMonth = (month) => {
//     setMonth(month);
//     localStorage.setItem("month",month);
//   };

//   // Scroll to the respective section
 

//   return (
//     <div className="container-fluid d-flex flex-column min-vh-100">
//       {/* Header */}
//       {/* <Navbar tableRef={tableRef} statisticRef={statisticRef} barChartRef={barChartRef} pieChartRef={pieChartRef} scrollToSection={scrollToSection}/> */}

//       {/* Main Content */}
//       <main
//         className="d-flex flex-column flex-grow-1 gap-3 p-3"
//         style={{ backgroundColor: "#f4f6f8" }}
//       >
//         {/* Transaction Table */}
//         <div ref={tableRef} className="bg-white rounded shadow-sm p-2">
//           <Table updateMonth={updateMonth} />
//         </div>

//         {/* Transaction Statistics */}
//         <div ref={statisticRef} className="bg-white rounded shadow-sm p-3">
//           <TransactionStatistic currMonth={localStorage.getItem('month') || 3} />
//         </div>

//         {/* Bar Chart Section */}
//         <div ref={barChartRef} className="row g-3">
//           <div className="col-12">
//             <div className="bg-white rounded shadow-sm p-3">
//               <h5 className="text-center">Bar Chart</h5>
//               <div className="border">
//                 <BarChart currMonth={localStorage.getItem('month') || 3} />
//               </div>
//             </div>
//           </div>
//         </div>

//         {/* Pie Chart Section */}
//         <div ref={pieChartRef} className="row g-3 mt-3">
//           <div className="col-12">
//             <div className="bg-white rounded shadow-sm p-3">
//               <h5 className="text-center">Pie Chart</h5>
//               <div
//                 className="d-flex justify-content-center align-items-center"
//                 style={{ height: "450px" }}
//               >
//                 <Chart currMonth={localStorage.getItem('month') || 3} />
//               </div>
//             </div>
//           </div>
//         </div>
//       </main>
//     </div>
//   );
// }

// export default All;

import { useState, useRef } from "react";
import Table from "./Table.jsx";
import { useNavigate } from "react-router-dom";
import TransactionStatistic from "./TransactionStatistic.jsx";
import Chart from "./PieChart.jsx";
import BarChart from "./BarChart.jsx";
import { 
  Table as TableIcon, 
  BarChart as BarChartIcon, 
  PieChart as PieChartIcon, 
  TrendingUp, 
  HomeIcon
} from 'lucide-react';

function TransactionDashboard() {
  const [currMonth, setMonth] = useState(3);
  const navigate = useNavigate(); // Add navigation hook

  // Create refs for each section
  const tableRef = useRef(null);
  const statisticRef = useRef(null);
  const barChartRef = useRef(null);
  const pieChartRef = useRef(null);

  const scrollToSection = (ref) => {
    ref.current.scrollIntoView({ behavior: "smooth" });
  };

  const updateMonth = (month) => {
    setMonth(month);
    localStorage.setItem("month", month);
  };

  // Navigation Component
  const DashboardNavigation = () => {
    const navItems = [
      {
        icon: <HomeIcon size={20} />, 
        label: 'Home', 
        onClick: () => navigate('/') // Navigate to home page
      },
      { 
        icon: <TableIcon size={20} />, 
        label: 'Transactions', 
        ref: tableRef 
      },
      { 
        icon: <TrendingUp size={20} />, 
        label: 'Statistics', 
        ref: statisticRef 
      },
      { 
        icon: <BarChartIcon size={20} />, 
        label: 'Bar Chart', 
        ref: barChartRef 
      },
      { 
        icon: <PieChartIcon size={20} />, 
        label: 'Pie Chart', 
        ref: pieChartRef 
      }
    ];

    return (
      <nav 
        className="d-flex justify-content-center mb-4 py-2" 
        style={{
          background: 'rgba(255,255,255,0.8)',
          backdropFilter: 'blur(10px)',
          borderRadius: '50px',
          boxShadow: '0 4px 6px rgba(0,0,0,0.05)'
        }}
      >
        {navItems.map((item, index) => (
          <button
            key={index}
            onClick={item.onClick || (item.ref ? () => scrollToSection(item.ref) : undefined)}
            className="btn d-flex align-items-center mx-2 px-3 py-2"
            style={{
              background: 'transparent',
              color: '#2c3e50',
              borderRadius: '25px',
              transition: 'all 0.3s ease'
            }}
          >
            {item.icon}
            <span className="ms-2 d-none d-md-inline">{item.label}</span>
          </button>
        ))}
      </nav>
    );
  };

  return (
    <div 
      className="container-fluid p-0" 
      style={{
        background: 'linear-gradient(135deg, #f4f5f7 0%, #e9ecef 100%)',
        fontFamily: "'Inter', sans-serif",
        minHeight: '100vh'
      }}
    >
      <div className="container-fluid px-3 px-md-5 py-4">
        {/* Header */}
        <header className="mb-4">
          <h1 
            className="text-center fw-bold mb-3" 
            style={{
              color: '#2c3e50', 
              fontSize: '2.5rem'
            }}
          >
            Transaction Dashboard
          </h1>
          <DashboardNavigation />
        </header>

        {/* Main Content */}
        <main className="d-flex flex-column gap-4">
          {/* Transaction Table */}
          <div 
            ref={tableRef} 
            className="rounded-4 shadow-sm" 
            style={{
              background: 'rgba(255,255,255,0.8)',
              backdropFilter: 'blur(10px)'
            }}
          >
            <Table updateMonth={updateMonth} />
          </div>

          {/* Transaction Statistics */}
          <div 
            ref={statisticRef} 
            className="rounded-4 shadow-sm" 
            style={{
              background: 'rgba(255,255,255,0.8)',
              backdropFilter: 'blur(10px)'
            }}
          >
            <TransactionStatistic currMonth={localStorage.getItem('month') || 3} />
          </div>

          {/* Charts Section */}
          <div className="row g-4">
            {/* Bar Chart */}
            <div ref={barChartRef} className="col-12 col-lg-6">
              <div 
                className="rounded-4 p-3 h-100" 
                style={{
                  background: 'rgba(255,255,255,0.8)',
                  backdropFilter: 'blur(10px)'
                }}
              >
                <h5 
                  className="text-center mb-3" 
                  style={{ color: '#2c3e50' }}
                >
                  Bar Chart Analysis
                </h5>
                <div className="border rounded-3 overflow-hidden">
                  <BarChart currMonth={localStorage.getItem('month') || 3} />
                </div>
              </div>
            </div>

            {/* Pie Chart */}
            <div ref={pieChartRef} className="col-12 col-lg-6">
              <div 
                className="rounded-4 p-3 h-100" 
                style={{
                  background: 'rgba(255,255,255,0.8)',
                  backdropFilter: 'blur(10px)'
                }}
              >
                <h5 
                  className="text-center mb-3" 
                  style={{ color: '#2c3e50' }}
                >
                  Pie Chart Insights
                </h5>
                <div 
                  className="d-flex justify-content-center align-items-center rounded-3 overflow-hidden" 
                  style={{ height: "450px" }}
                >
                  <Chart currMonth={localStorage.getItem('month') || 3} />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default TransactionDashboard;

